import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { io, Socket } from "socket.io-client";
import { GameState, Card } from "@/lib/game";

interface SocketContextType {
  socket: Socket | null;
  connected: boolean;
  gameState: GameState | null;
  error: string | null;
  connect: () => void;
  createRoom: (name: string, matchTarget?: number, matchLabel?: string) => Promise<{ roomCode?: string; playerIndex?: number }>;
  joinRoom: (code: string, name: string) => Promise<{ playerIndex?: number }>;
  reconnect: (roomCode: string, playerIndex: 0 | 1, playerName: string) => Promise<{ ok: boolean }>;
  startGame: (code: string) => void;
  placeBid: (code: string, amount: number) => Promise<void>;
  playCard: (code: string, card: Card) => Promise<void>;
  nextRound: (code: string) => void;
  newMatch: (code: string) => void;
  joinAsSpectator: (code: string, name: string) => Promise<void>;
  reconnectAsSpectator: (code: string, name: string) => Promise<void>;
}

const SocketContext = createContext<SocketContextType | null>(null);

export function SocketProvider({ children }: { children: ReactNode }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const s = io({ path: "/socket.io", autoConnect: false });
    setSocket(s);

    s.on("connect", () => setConnected(true));
    s.on("disconnect", () => setConnected(false));
    
    s.on("game_state", (state: GameState) => {
      setGameState(state);
      setError(null);
    });

    s.on("opponent_joined", () => {});
    s.on("round_started", () => {});
    s.on("bid_placed", () => {});
    s.on("trick_complete", () => {});
    s.on("round_over", () => {});
    s.on("opponent_disconnected", () => {
      setError("Opponent disconnected. Waiting for them to rejoin...");
    });
    s.on("opponent_reconnected", () => {
      setError(null);
    });

    return () => {
      s.disconnect();
    };
  }, []);

  const connect = () => {
    if (socket && !socket.connected) {
      socket.connect();
    }
  };

  const createRoom = (playerName: string, matchTarget?: number, matchLabel?: string) => {
    return new Promise<{ roomCode?: string; playerIndex?: number }>((resolve, reject) => {
      if (!socket) return reject("No socket");
      socket.emit("create_room", { playerName, matchTarget, matchLabel }, (res: any) => {
        if (res.ok) resolve({ roomCode: res.roomCode, playerIndex: res.playerIndex });
        else reject(res.error);
      });
    });
  };

  const joinRoom = (roomCode: string, playerName: string) => {
    return new Promise<{ playerIndex?: number }>((resolve, reject) => {
      if (!socket) return reject("No socket");
      socket.emit("join_room", { roomCode, playerName }, (res: any) => {
        if (res.ok) resolve({ playerIndex: res.playerIndex });
        else reject(res.error);
      });
    });
  };

  const startGame = (roomCode: string) => {
    socket?.emit("start_game", { roomCode });
  };

  const placeBid = (roomCode: string, amount: number) => {
    return new Promise<void>((resolve, reject) => {
      socket?.emit("place_bid", { roomCode, amount }, (res: any) => {
        if (res.ok) resolve();
        else reject(res.error);
      });
    });
  };

  const playCard = (roomCode: string, card: Card) => {
    return new Promise<void>((resolve, reject) => {
      socket?.emit("play_card", { roomCode, card }, (res: any) => {
        if (res.ok) resolve();
        else reject(res.error);
      });
    });
  };

  const reconnect = (roomCode: string, playerIndex: 0 | 1, playerName: string) => {
    return new Promise<{ ok: boolean }>((resolve, reject) => {
      if (!socket) return reject("No socket");
      socket.emit(
        "reconnect_player",
        { roomCode, playerIndex, playerName },
        (res: { ok: boolean; error?: string }) => {
          if (res.ok) resolve({ ok: true });
          else reject(res.error);
        }
      );
    });
  };

  const nextRound = (roomCode: string) => {
    socket?.emit("next_round", { roomCode });
  };

  const newMatch = (roomCode: string) => {
    socket?.emit("new_match", { roomCode });
  };

  const joinAsSpectator = (roomCode: string, spectatorName: string) => {
    return new Promise<void>((resolve, reject) => {
      if (!socket) return reject("No socket");
      socket.emit(
        "join_as_spectator",
        { roomCode, spectatorName },
        (res: { ok: boolean; error?: string }) => {
          if (res.ok) resolve();
          else reject(res.error);
        }
      );
    });
  };

  const reconnectAsSpectator = (roomCode: string, spectatorName: string) => {
    return new Promise<void>((resolve, reject) => {
      if (!socket) return reject("No socket");
      socket.emit(
        "reconnect_spectator",
        { roomCode, spectatorName },
        (res: { ok: boolean; error?: string }) => {
          if (res.ok) resolve();
          else reject(res.error);
        }
      );
    });
  };

  return (
    <SocketContext.Provider value={{
      socket,
      connected,
      gameState,
      error,
      connect,
      createRoom,
      joinRoom,
      reconnect,
      startGame,
      placeBid,
      playCard,
      nextRound,
      newMatch,
      joinAsSpectator,
      reconnectAsSpectator
    }}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  const ctx = useContext(SocketContext);
  if (!ctx) throw new Error("useSocket must be used within SocketProvider");
  return ctx;
}
